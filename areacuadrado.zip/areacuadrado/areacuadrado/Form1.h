#pragma once

namespace areacuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btbcalcular;
	private: System::Windows::Forms::TextBox^  txtlado;
	private: System::Windows::Forms::TextBox^  txtarea;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btbcalcular = (gcnew System::Windows::Forms::Button());
			this->txtlado = (gcnew System::Windows::Forms::TextBox());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(83, 116);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(27, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"lado";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(86, 170);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(28, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"area";
			// 
			// btbcalcular
			// 
			this->btbcalcular->Location = System::Drawing::Point(131, 213);
			this->btbcalcular->Name = L"btbcalcular";
			this->btbcalcular->Size = System::Drawing::Size(75, 23);
			this->btbcalcular->TabIndex = 2;
			this->btbcalcular->Text = L"calcular";
			this->btbcalcular->UseVisualStyleBackColor = true;
			this->btbcalcular->Click += gcnew System::EventHandler(this, &Form1::btbcalcular_Click);
			// 
			// txtlado
			// 
			this->txtlado->Location = System::Drawing::Point(168, 108);
			this->txtlado->Name = L"txtlado";
			this->txtlado->Size = System::Drawing::Size(100, 20);
			this->txtlado->TabIndex = 3;
			this->txtlado->TextChanged += gcnew System::EventHandler(this, &Form1::txtlado_TextChanged);
			// 
			// txtarea
			// 
			this->txtarea->Location = System::Drawing::Point(168, 162);
			this->txtarea->Name = L"txtarea";
			this->txtarea->Size = System::Drawing::Size(100, 20);
			this->txtarea->TabIndex = 4;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(459, 407);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->txtlado);
			this->Controls->Add(this->btbcalcular);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"area del cuadrado";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbcalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 int lado,Area;
				 lado=System::Covert::ToInt32(txtlado->Text);
				 Area=lado*lado;
				 txtarea->Text = Area.ToString();

			 }

};
}

