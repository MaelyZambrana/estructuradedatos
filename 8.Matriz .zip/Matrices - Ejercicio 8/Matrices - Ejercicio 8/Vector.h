#pragma once

const int TAM = 120;

class Vector
{
	double arr[TAM];
	int tam;
public:
	Vector(void);
	void setValor(int, double);
	void setTam(int);
	double getValor(int);
	int getTam();
};

