#include "StdAfx.h"
#include "Operaciones.h"

// METODOS PRIVADOS
void Operaciones::llenarVector(Vector& arr){
	for(int i=0; i<N; i++)
		arr.setValor(i, 0.0);
}

void Operaciones::llenarVector(Vector& arr, int tam){
	for(int i=0; i<tam; i++)
		arr.setValor(i, 0.0);
}

void Operaciones::promedioPorFila(Vector& arr){
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<6; j++)
			arr.setValor(i, arr.getValor(i)+getValorMatriz(i, j));
		arr.setValor(i, arr.getValor(i)/6.0);
	}
}

void Operaciones::promedioPorColumna(Vector& arr){
	for(int j=0; j<6; j++){
		for(int i=0; i<getFilas(); i++)
			arr.setValor(j, arr.getValor(j) + getValorMatriz(i, j));
		arr.setValor(j, arr.getValor(j)/getFilas());
	}
}
// METODOS PUBLICOS
Operaciones::Operaciones(void)
{
	Matriz();
	Vector();
}

void Operaciones::guardarDatos(DataGridView^ dgv){
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<6; j++)
			setValorMatriz(i, j, Convert::ToDouble(dgv->Rows[i]->Cells[j]->Value));
	}
}

void Operaciones::notaPromedioEstudiantes(DataGridView^ dgv){
	Vector resParcial; resParcial.setTam(N);
	llenarVector(resParcial);
	promedioPorFila(resParcial);

	dgv -> RowCount = getFilas();
	dgv -> ColumnCount = 1;
	for(int i=0; i<getFilas(); i++)
		dgv->Rows[i]->Cells[0]->Value = resParcial.getValor(i);
}

void Operaciones::cantidadDeAprobados(){
	Vector arr; arr.setTam(N);
	llenarVector(arr);
	promedioPorFila(arr);

	int aprobados = 0;
	for(int i=0; i<getFilas(); i++){
		if(arr.getValor(i) >= 51.0)
			aprobados++;
	}

	MessageBox::Show("Aprobados: " + Convert::ToString(aprobados));
}

void Operaciones::cantidadDeReprobados(){
	Vector arr; arr.setTam(N);
	llenarVector(arr);
	promedioPorFila(arr);

	int reprobados = 0;
	for(int i=0; i<getFilas(); i++){
		if(arr.getValor(i) < 51.0)
			reprobados++;
	}

	MessageBox::Show("Reprobados: " + Convert::ToString(reprobados));
}

void Operaciones::notaPromedioMaterias(DataGridView^ dgv){
	Vector resParcial; resParcial.setTam(6);
	llenarVector(resParcial, 6);
	
	dgv -> RowCount = 1;
	dgv -> ColumnCount = 6;

	promedioPorColumna(resParcial);

	for(int i=0; i<6; i++)
		dgv->Rows[0]->Cells[i]->Value = resParcial.getValor(i);
}
